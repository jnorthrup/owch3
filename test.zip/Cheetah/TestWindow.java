



package Cheetah;

import javax.swing.*;



public class TestWindow extends JFrame{
    public     TestWindow()
    {
	show();
	setTitle("success");
    };
    public  static void  main(String[]args){
	new TestWindow();
	try{	Thread.currentThread().sleep(10000);}catch(Exception e){};
    };
};
